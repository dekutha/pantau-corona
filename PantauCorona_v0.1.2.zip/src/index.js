/*
        jangan ubah kode di bawah ini ya!
*/

import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/main.css";
import "./script/component/footerSection.js";
import "./script/component/headerSection.js";
import main from "./script/view/main.js";

document.addEventListener("DOMContentLoaded", main);