# PantauCorona
simple media interface for showing coronavirus (SARS-CoV-19) outbreak especially in Indonesia

### Credit
1. [covid-19-api](https://github.com/mathdroid/covid-19-api) & [indonesia-covid-19-api](https://github.com/mathdroid/indonesia-covid-19-api)by [mathdroid](https://github.com/mathdroid).

### License
MIT